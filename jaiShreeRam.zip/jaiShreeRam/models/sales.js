// const mongoose=require("mongoose");
// const path=require('path');
// const Customer_Schema = new mongoose.Schema({
//     customerid:{
//         type:String,
//         required:true
//     },
//     booked_items:{
//         type: [String],
//         required:true
//     },


// },{
//     timestamps:true
// });


// const Customer =mongoose.model('Customer',Customer_Schema);

// module.exports = Customer;