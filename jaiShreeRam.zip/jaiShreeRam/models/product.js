const mongoose=require("mongoose");
const path=require('path');
const product_Schema = new mongoose.Schema({
    item_name:{
        type:String,
        required:true
    },
    total_quantity:{
        type:Number,
        required:true,
        
    },
    rate:{
        type:Number,
        required:true
    },
    available_quantity:{
        type:Number,
        required:true
    }
}
,{
    timestamps:true
});


const Product =mongoose.model('product',product_Schema);

module.exports =Product;