const mongoose=require("mongoose");
const path=require('path');
const Customer_Schema = new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    address:{
        type:String,
        required:true,
    },
    phone:{
        type:String,
        required:true
    },
    aadhaar:{
        type:String,
        required:true
    },
    total_amount:{
       type:String,
       required:true
    },
    advanced_pay:{
        type:Number,
        required:true
    },
    remaining_pay:{
        type:Number,
        required:true
    },
    event_date:{
        type:Date,
        required:true
    },
    returning_date:{
        type:Date,
        required:true
    },
    booked_items:{
        type: Object,
        required:true
    },
    isreturn:{
        type:Boolean,
        default:false
    }

},{
    timestamps:true
});


const Customer =mongoose.model('Customer',Customer_Schema);

module.exports = Customer;