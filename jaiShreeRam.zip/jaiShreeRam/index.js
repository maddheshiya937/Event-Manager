const express =require("express");
const bodyParser = require('body-parser');
const app =express();
const port=8000;
const db=require('./config/mongoose');
app.use(express.urlencoded({extended:true}));


const temp=require('./routes/index');


app.use(bodyParser.urlencoded({extended:true}));
temp.use(bodyParser.json())

//use express route 
app.use('/',temp);


// set up the view engine 
app.set('view engine','ejs');
app.set('views','./views'); 


//listing the server
app.listen(port,function(error){
    if(error){
        console.log("Error:",err);
        console.log(`Error in running the server: ${error}`);
    }
    console.log(`server is running on port":${port}`);
}); 