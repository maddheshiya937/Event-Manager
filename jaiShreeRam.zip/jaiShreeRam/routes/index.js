const express = require("express");
const router = express.Router();
const sign_up = require("../models/sign_up");
const product = require("../models/product");
const customerDetails = require("../models/customer");
const mongoose = require("../config/mongoose");

const homeController = require("../controllers/home_controller");
const { render } = require("express/lib/response");
// const product = require('../models/product');

// router.get('/',homeController.signup);
router.get("/signin", homeController.signin);
router.get("/signup", homeController.signup);
router.get("/additem", homeController.additem);
router.get("/update_item", homeController.update_item);
router.get("/itemList", homeController.itmeList);
router.get("/bookItems", homeController.bookItems);
router.get("/", homeController.home);
router.get("/orders", homeController.orders);

router.get("/return", async (req, res) => {
  const id = req.query.id;
  try {
    const customer = await customerDetails.findOne({ _id: id });
    const items = customer.booked_items;
    if(customer.isreturn==true){
      return res.send("already retured");
    }
    // console.log(items);

    for (const item in items) {
      const quantity = items[item];
      let ordered_product = await product.findOne({ item_name: item });
      // console.log(doc.item_name, doc.id, doc.available_quantity);
      let prevVal = ordered_product.available_quantity;
      let newVal = parseInt(prevVal) + parseInt(quantity);
      try {
        ordered_product.available_quantity = newVal;
        ordered_product.save();
      } catch (errrr) {
        return res.send(errrr);
      }
      console.log("item: ", item);
      // console.log(doc1.item_name, doc1.id, doc1.available_quantity);
    }
  } catch (err) {
    console.log(err);
    return res.send("something went wrong");
  }

  try {
    const order = await customerDetails.findOne({ _id:id });
    // if(order.isreturn == true){
    //   return res.send("you have already returned this order");
    // }
    order.isreturn = true;
    order.save();
    return res.render("orders",result=await customerDetails.find());
  } catch (err) {
    return res.send(err);
  }
});

router.post("/sign_up", function (req, res) {
  sign_up.create(
    {
      name: req.body.name,
      email: req.body.email,
      password: req.body.password,
      phone: req.body.phone,
      address: req.body.address,
    },
    function (error, newdata) {
      if (error) {
        console.log("error in creating  a new data list:");
        return;
      }
    }
  );
  return res.redirect("back");
});

router.post("/addItem", function (req, res) {
  // console.log("heyy this is additem call");
  product.create(
    {
      item_name: req.body.item_name,
      total_quantity: req.body.total_quantity,
      available_quantity: req.body.available_quantity,
      rate: req.body.rate,
    },
    function (error, newdata) {
      if (error) {
        console.log("error in creating  a new data list:");
        return;
      }
    }
  );
  return res.redirect("back");
});

router.post("/details", async function (req, res) {
  //  console.log("heyy this is add customer details call");
  // console.log(req.body);
  // console.log(req.body.booked_items);

  const booked_items = JSON.parse(req.body.booked_items);
  // console.log(booked_items);
  for (const item in booked_items) {
    // console.log(item);
    const need = booked_items[item];
    let doc = await product.findOne({ item_name: item });
    // console.log(doc.item_name, doc.id, doc.available_quantity);
    let prevVal = doc.available_quantity;
    let newVal = prevVal - need;
    if(newVal<0){
      return res.send("You demand more than avaliable Quantity");
    }
    await product.findOneAndUpdate(
      { item_name: item },
      { available_quantity: newVal },
      { new: true }
    );
    // console.log(doc1.item_name, doc1.id, doc1.available_quantity);
  }
  customerDetails.create(
    {
      name: req.body.name,
      phone: req.body.phone,
      aadhaar: req.body.aadhaar,
      address: req.body.address,
      total_amount: req.body.total_amount,
      advanced_pay: req.body.advanced_pay,
      remaining_pay: req.body.remaining_pay,
      booked_items: JSON.parse(req.body.booked_items),
      event_date: req.body.event_date,
      returning_date: req.body.returning_date,
    },
    function (error, newdata) {
      if (error) {
        console.log(error.message);
        return;
      }
    }
  );
  return res.redirect("/");
});

// router.get("/update",function(req,res){
//     conlsole.log('is here it is')
//     product.find({},function(err,products){
//         if(err){
//             console.log('Error in fetching the data from dtabse');
//             return ;
//         }
//         console.log(products)
//         return res.render('home');
//     })
//     return res.redirect('back');
// })

router.get("/update", function (req, res) {
  additem.create(
    {
      item_name: req.body.item_name,
      total_quantity: req.body.total_quantity,
      available_quantity: req.body.available_quantity,
      rate: req.body.rate,
      // Date:req.body.Date
    },
    function (error, newdata) {
      if (error) {
        console.log("error in creating  a new data list:");
        return;
      }
    }
  );
  return res.redirect("back");
});

// router.get("/findorders", (req, res) => {
//   customerDetails.find({ remaining_pay: { $gt: 0 } }, (err, result) => {
//     if (err) {
//       console.log(err);
//       res.send("error");
//     } else {
//       console.log(result);
//       res.render("orders", result);
//     }
//   });
// });

module.exports = router;
