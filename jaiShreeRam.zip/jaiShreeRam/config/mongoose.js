const mongoose=require("mongoose");
const  db  = require("../models/sign_up");
mongoose.connect("mongodb://localhost/jaiShreeRam");

const dp=mongoose.connection;

db.on("error",console.error.bind(console,"error connecting to db"));

db.once("open",function(){
   console.log("dataBase successfully connected to the database");
});