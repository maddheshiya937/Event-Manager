const { append } = require("express/lib/response")
const product = require("../models/product")
const express =require('express');
const Customer = require("../models/customer");
const app =express();
const router=express.Router();
module.exports.signup=function(req,res){
    return res.render("sign_up",{
       title:"jaiShreeRam | Sign Up"
    })
 }
 module.exports.home=function(req,res){
   return res.render("home",{
      title:"jaiShreeRam | home"
   })
}

module.exports.signin=function(req,res){
   return res.render("sign_in",{
      title:"jaiShreeRam | Sign In"
   })
}

module.exports.additem=function(req,res){
   return res.render("additem",{
      title:"jaiShreeRam | additem "
   })
}

module.exports.bookItems=async function(req,res){
   // return res.render("book_item",{
   //    title:"jaiShreeRam | book items "
   // })
   try{
      items=await product.find({})
      // console.log(items);
      const {item_name,rate}=items;
      return res.render("book_item",items)
   }catch(err){
      console.log(err);
   }
}



module.exports.update_item=async function(req,res){
   //  item=[];
   try{
      items=await product.findOne({})
      // console.log(items);
      const {item_name,rate}=items;
      return res.render("update_item",items)
   }catch(err){
      console.log(err);
   }
}

module.exports.itmeList=async function(req,res){
   //  item=[];
   try{
      items=await product.find({})
      // console.log(items);
      const {item_name,rate}=items;
      return res.render("itemList",items)
   }catch(err){
      console.log(err);
   }
}

module.exports.orders=async function(req,res){
   try{
      result=await Customer.find({})
      // console.log(items);
      // const {item_name,rate}=items;
      return res.render("orders",result);
   }catch(err){
      console.log(err);
   }
}



